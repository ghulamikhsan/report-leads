
<?php $__env->startSection('title'); ?>
     Management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- breadcumb -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 float-right">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#"><?php echo e(auth()->user()->name); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h2 class="card-title">Management Detail Laporan</h2>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
                                        <button type="button"
                                            class="btn btn-outline-primary btn-sm waves-effect waves-light float-right"
                                            id="createNewItem">Buat Laporan Customer Baru</button>
                                        <button type="button"
                                            class="btn btn-outline-primary btn-sm waves-effect waves-light float-right"
                                            id="createNewItem2">Buat Laporan Customer Lama</button>
                                    <?php endif; ?>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <table id="example2" class="table table-bordered table-hover data-table">
                                        <thead>
                                            <tr>
                                                <th>Tanggal</th>
                                                <th>Nama Customer</th>
                                                <th>Nomor Whatsapp</th>
                                                <th>Informasi Customer</th>
                                                <th>Pesanan</th>
                                                <th>QTY</th>
                                                <th>Keterangan</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <!-- /.content-header -->
    </div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
        <div class="modal fade" id="ajaxModel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modelHeading"></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="ItemForm" name="ItemForm" class="form-horizontal">
                            <input type="hidden" name="Item_id" id="Item_id">
                            <input type="hidden" name="created_by" id="created_by" value="<?php echo e(auth()->user()->id); ?>">
                            <input type="hidden" name="customer_information" value="Baru" class="form-control" readonly>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Tanggal</label>
                                            <?php echo Form::date('date', null, ['placeholder' => 'Tanggal', 'class' => 'form-control']); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Nama Customer</label>
                                            <?php echo Form::text('namec', null, ['placeholder' => 'Nama Customer', 'class' => 'form-control']); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Alamat Asal</label>
                                            <?php echo Form::text('orign', null, ['placeholder' => 'Alamat Asal', 'class' => 'form-control']); ?>

                                        </div>
                                    </div>    
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Nomor Whatsapp</label>
                                            <?php echo Form::number('no_wa', null, ['placeholder' => 'Nomor Whatsapp', 'class' => 'form-control']); ?>

                                        </div>
                                    </div>         
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Pesanan</label>
                                            <?php echo Form::text('order', null, ['placeholder' => 'Pesanan', 'class' => 'form-control']); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label>QTY</label>
                                            <?php echo Form::number('qty', null, ['placeholder' => 'QTY', 'class' => 'form-control']); ?>

                                        </div>
                                    </div>         
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <?php echo Form::textarea('description', null, ['placeholder' => 'Keterangan', 'class' => 'form-control']); ?>

                                        </div>
                                    </div>
                                </div>         
                            </div>
                            <div class="col-sm-offset-2 col-sm-10">
                                <button class="btn btn-primary tombol" id="saveBtn" value="create"></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="ajaxModel2" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modelHeading2"></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="ItemForm2" name="ItemForm2" class="form-horizontal">
                            <input type="hidden" name="Item_id" id="Item_id">
                            <input type="hidden" name="created_by" id="created_by" value="<?php echo e(auth()->user()->id); ?>">
                            <input type="hidden" name="customer_information" value="Lama" class="form-control" readonly>
                            
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Tanggal</label>
                                            <?php echo Form::date('date', null, ['placeholder' => 'Tanggal', 'class' => 'form-control']); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Nama Customer</label>
                                            
                                            <select id="id_customer" name="id_customer" class="selectpicker form-control" data-live-search="true">
                                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </select>
                                        </div>
                                    </div>   
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Pesanan</label>
                                            <?php echo Form::text('order', null, ['placeholder' => 'Pesanan', 'class' => 'form-control']); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label>QTY</label>
                                            <?php echo Form::number('qty', null, ['placeholder' => 'QTY', 'class' => 'form-control']); ?>

                                        </div>
                                    </div>         
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <?php echo Form::textarea('description', null, ['placeholder' => 'Keterangan', 'class' => 'form-control']); ?>

                                        </div>
                                    </div>
                                </div>         
                            </div>
                            <div class="col-sm-offset-2 col-sm-10">
                                <button class="btn btn-primary tombol" id="saveBtn2" value="create"></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css-tambahan'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('cdn/datatables/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cdn/datatables/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cdn/datatables/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-tambahan'); ?>
    <!-- DataTables  & Plugins -->
    <script src="<?php echo e(asset('cdn/datatables/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn/datatables/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn/datatables/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn/datatables/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn/datatables/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn/datatables/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script type="text/javascript">
        $(function() {

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('.data-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('laporan.index')); ?>",
                pageLength: 5,
                lengthMenu: [5, 10, 20, 50, 100, 200, 500],
                esponsive: true,
                lengthChange: false,
                autoWidth: false,
                columns: [
                    {
                        data: 'date',
                        name: 'date'
                    },
                    {
                        data: 'customer_name',
                        name: 'customer_name'
                    },
                    {
                        data: 'number',
                        name: 'number'
                    },
                    {
                        data: 'customer_information',
                        name: 'customer_information'
                    },
                    {
                        data: 'order',
                        name: 'order'
                    },
                    {
                        data: 'qty',
                        name: 'qty'
                    },
                    {
                        data: 'description',
                        name: 'description'
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]
            });

            $('#createNewItem').click(function() {
                $('#saveBtn').val("create-Item");
                $('#Item_id').val('');
                $('#ItemForm').trigger("reset");
                $('#modelHeading').html("Buat Laporan Customer Baru");
                $('.tombol').html("Submit");
                $('#ajaxModel').modal('show');
            });
            $('#createNewItem2').click(function() {
                $('#saveBtn2').val("create-Item");
                $('#Item_id').val('');
                $('#ItemForm2').trigger("reset");
                $('#modelHeading2').html("Buat Laporan Customer Lama");
                $('.tombol').html("Submit");
                $('#ajaxModel2').modal('show');
            });
            
            // <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
            //     $('body').on('click', '.editItem', function() {
            //     var Item_id = $(this).data('id');
            //     $('.tombol').html("Save Change");
            //     $.get("<?php echo e(route('laporan.index')); ?>" + '/' + Item_id + '/edit', function(data) {
            //     $('#modelHeading').html("Edit Item");
            //     $('#saveBtn').val("edit-laporan");
            //     $('#ajaxModel').modal('show');
            //     $('#Item_id').val(data.id);
            //     $('input[name=date]').val(data.date);
            //     $('input[name=customer_name]').val(data.customer_name);
            //     $('input[name=number]').val(data.number);
            //     $('input[name=order]').val(data.order);
            //     $('input[name=id_customer]').val(data.id_customer);
            //     $('input[name=qty]').val(data.qty);
            //     $('input[name=description]').val(data.description);
            //     $('input[name=created_by]').val(data.created_by);
            //     })
            //     });
            
                $('#saveBtn').click(function(e) {
                e.preventDefault();
                $.ajax({
                data: $('#ItemForm').serialize(),
                url: "<?php echo e(route('laporan.store')); ?>",
                type: "POST",
                dataType: 'json',
                success: function(response) {
                if (response.success) {
                Swal.fire({
                icon: "success",
                title: "Selamat",
                text: response.success
                });
                $('#ItemForm').trigger("reset");
                $('#ajaxModel').modal('hide');
                table.draw();
                } else {
                Swal.fire({
                icon: "error",
                title: "Mohon Maaf !",
                text: response.error
                });
                }
                },
                error: function() {
                Swal.fire({
                icon: "error",
                title: "Oops...",
                text: "Something went wrong!"
                });
                }
                });
                });

                $('body').on('click', '.editItem', function() {
                var Item_id = $(this).data('id');
                $('.tombol').html("Save Change");
                $.get("<?php echo e(route('laporan.index')); ?>" + '/' + Item_id + '/edit', function(data) {
                $('#modelHeading').html("Edit Item");
                $('#saveBtn2').val("edit-laporan");
                $('#ajaxModel2').modal('show');
                $('#Item_id').val(data.id);
                $('input[name=date]').val(data.date);
                $('input[name=name]').val(data.name);
                $('input[name=no_wa]').val(data.no_wa);
                $('input[name=order]').val(data.order);
                $('input[name=qty]').val(data.qty);
                $('input[name=description]').val(data.description);
                $('input[name=created_by]').val(data.created_by);
                })
                });
            
                $('#saveBtn2').click(function(e) {
                e.preventDefault();
                $.ajax({
                data: $('#ItemForm2').serialize(),
                url: "<?php echo e(route('laporancustlama.store')); ?>",
                type: "POST",
                dataType: 'json',
                success: function(response) {
                if (response.success) {
                Swal.fire({
                icon: "success",
                title: "Selamat",
                text: response.success
                });
                $('#ItemForm2').trigger("reset");
                $('#ajaxModel').modal('hide');
                table.draw();
                } else {
                Swal.fire({
                icon: "error",
                title: "Mohon Maaf !",
                text: response.error
                });
                }
                },
                error: function() {
                Swal.fire({
                icon: "error",
                title: "Oops...",
                text: "Something went wrong!"
                });
                }
                });
                });
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-delete')): ?>
                $('body').on('click', '.deleteItem', function() {
            
                var Item_id = $(this).data("id");
                var url = $(this).data("url");
                Swal.fire({
                title: 'Apakah Anda Yakin ?',
                text: "Anda Akan Menghapus Data Ini !",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                if (result.isConfirmed) {
                $.ajax({
                type: "DELETE",
                url: url,
                success: function(response) {
                if (response.success) {
                Swal.fire({
                icon: "success",
                title: "Selamat",
                text: response.success
                });
                $('#ItemForm').trigger("reset");
                $('#ajaxModel').modal('hide');
                table.draw();
                } else {
                Swal.fire({
                icon: "error",
                title: "Mohon Maaf !",
                text: response.error
                });
                }
                },
                error: function() {
                Swal.fire({
                icon: "error",
                title: "Oops...",
                text: "Something went wrong!"
                });
                }
                });
                }
                })
                });
            <?php endif; ?>
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_spatie_role_8-master\resources\views/laporan/index.blade.php ENDPATH**/ ?>