<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\CreateReport;
use App\Models\Report;
use App\Models\User;
use App\Models\Laporan;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Symfony\Component\VarDumper\Cloner\Data;

class DetailController extends Controller
{
    public function index()
    {
        $names = User::get();

        return view('detail.index', compact('names'));
    }

    public function indextgl()
    {
        $months = Laporan::get()
            ->groupBy('date');

        return view('detail.indextgl', compact('months'));
    }

    public function show($created_by)
    {
        $report = Laporan::find($created_by);
        // $report = DB::table('laporans')->where('created_by', auth()->user()->id)->get();
        $counts_lama = DB::table("laporans")
            ->join('users', 'laporans.created_by', '=', 'users.id')
            ->select("date", DB::raw("COUNT(customer_information) as status"))
            ->where("customer_information", '=', 'lama')
            ->where('users.id', $created_by)
            ->groupBy("date")
            ->get();
        // dd($counts_lama);
        $counts_baru = DB::table("laporans")
            ->join('users', 'laporans.created_by', '=', 'users.id')
            ->select("date", DB::raw("COUNT(customer_information) as status"))
            ->where("customer_information", '=', 'baru')
            ->where('users.id', $created_by)
            ->groupBy("date")
            ->get();
        $laporans =  DB::table('laporans')
            ->join('customers', 'laporans.id_customer', '=', 'customers.id')
            ->join('users', 'laporans.created_by', '=', 'users.id')
            ->select('laporans.id', 'laporans.date', 'laporans.deal', 'laporans.customer_information', 'customers.no_wa', 'customers.name', 'laporans.qty', 'laporans.order', 'laporans.description', 'users.name as uname')
            ->where('users.id', $created_by)
            ->get();
        // dd($counts_baru);
        return view('detail.showuser', compact('report', 'counts_lama', 'counts_baru', 'laporans'));
    }

    public function showtgl($date)
    {
        $months = DB::table('laporans')
            ->join('customers', 'laporans.id_customer', '=', 'customers.id')
            ->join('users', 'laporans.created_by', '=', 'users.id')
            ->select('laporans.id', 'laporans.date', 'laporans.deal', 'laporans.customer_information', 'laporans.no_wa', 'customers.name', 'laporans.qty', 'laporans.order', 'laporans.description', 'users.name as uname')
            ->get()
            ->where('date', $date)
            ->groupBy('date');
        // dd($months);
        return view('detail.showtgl', compact('months'));
    }
}
