<?php

namespace App\Http\Controllers;

use App\Models\Laporan;
use App\Models\Customer;
use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class LaporanController extends Controller
{
    // function __construct()
    // {
    //     $this->middleware('permission:report-view', ['only' => ['index', 'edit']]);
    //     $this->middleware('permission:report-create', ['only' => ['store']]);
    //     $this->middleware('permission:report-delete', ['only' => ['destroy']]);
    // }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Laporan::join('customers', 'laporans.id_customer', '=', 'customers.id')
                ->join('users', 'laporans.created_by', '=', 'users.id')
                ->select('laporans.*', 'customers.name as customer_name', 'customers.no_wa as number')
                ->where('users.id', '=', auth()->user()->id)
                ->latest()
                ->get();
            // dd($data);
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $btn = '<a href="javascript:void(0)" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Edit" class="edit btn btn-primary btn-sm editItem"><i class="fas fa-edit"></i></a>';
                    $btn = $btn . ' <a href="javascript:void(0)" data-toggle="tooltip"  data-id="' . $row->id . '" data-url="' . route('laporan.destroy', $row->id) . '" data-original-title="Delete" class="btn btn-danger btn-sm deleteItem"><i class="fas fa-trash"></i></a>';
                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        $customers = Customer::get();

        return view('laporan.index', compact('customers'));
    }

    public function store(Request $request)
    {
        if ($request->Item_id == '') {
            $validator = Validator::make($request->all(), [
                'date' => 'required',
                'customer_information' => 'required',
                // 'id_customer' => 'required',
                'qty' => 'required',
                'order' => 'required',
                'description' => 'required',
            ]);
        } else {
            $validator = Validator::make($request->all(), [
                'Item_id' => 'required',
                'date' => 'required',
                'customer_information' => 'required',
                // 'id_customer' => 'required',
                'qty' => 'required',
                'order' => 'required',
                'description' => 'required',
            ]);
        }

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()->all()], 200);
        }

        $cust = Customer::insertGetId(
            [
                'name' => $request->namec,
                'no_wa' => $request->no_wa,
                'orign' => $request->orign,
                'created_by' => $request->created_by
            ]
        );

        Laporan::UpdateOrCreate(
            ['id' => $request->Item_id],
            [
                'date' => $request->date,
                'customer_information' => $request->customer_information,
                'no_wa' => $request->no_wa,
                'id_customer' => $cust,
                'qty' => $request->qty,
                'order' => $request->order,
                'description' => $request->description,
                'created_by' => $request->created_by
            ]
        );

        return response()->json(['success' => 'Item deleted successfully.']);
    }

    public function edit($id)
    {
        $item = Laporan::find($id);
        return response()->json($item);
    }

    public function destroy($id)
    {
        Laporan::find($id)->delete();
        return Response()->json(['success' => 'Laporan Berhasil dihapus']);
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'date' => 'required',
            'customer_information' => 'required',
            // 'id_customer' => 'required',
            'qty' => 'required',
            'order' => 'required',
            'description' => 'required',
        ]);
        $input = $request->all();

        $item = Laporan::find($id);
        $item->update($input);
        return redirect()->route('laporan.index')
            ->with('success', 'laporan updated successfully');
    }
}
