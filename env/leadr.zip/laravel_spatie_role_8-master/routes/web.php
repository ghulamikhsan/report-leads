<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();


Route::group(['middleware' => ['auth', 'dontback']], function () {
    Route::get('/home', [App\Http\Controllers\Home\HomeController::class, 'index'])->name('home');
    Route::resource('dashboard/roles', App\Http\Controllers\Role\RoleController::class);
    Route::resource('dashboard/permissions', App\Http\Controllers\Role\PermissionsController::class);
    Route::resource('dashboard/users', App\Http\Controllers\User\UserController::class);
    Route::resource('customer', App\Http\Controllers\CustomerController::class);
    Route::resource('laporan', App\Http\Controllers\LaporanController::class);
    Route::resource('laporancustlama', App\Http\Controllers\LaporanLamaController::class);
    route::resource('master', App\Http\Controllers\MasterController::class);
    route::resource('detail', App\Http\Controllers\DetailController::class);
    route::get('detailtgl', [App\Http\Controllers\DetailController::class, 'indextgl'])->name('detailtgl');
    route::get('detailtgl/{detail}', [App\Http\Controllers\DetailController::class, 'showtgl'])->name('detailtgl.show');
});
